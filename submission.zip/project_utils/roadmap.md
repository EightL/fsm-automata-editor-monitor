### Road-map for “Visual Editor, Code Generator & Monitor of Interpreted Timed Finite-State Machines”  
*Aligned line-by-line with `specification.md` (April 2025)*  

---

## 0  Principles

- **Simplicity and is key**: Make the implementations as CLEAN and AS SIMPLE AS IT GETS.
- **Slow but consistent**: Take things slowly, be skeptical about our implementation, always check if it aligns with the roadmap and specification.

| Principle | Why (spec ref.) | Practical consequence |
|-----------|-----------------|-----------------------|
| **Keep model ↔ GUI separated** | “Návrh musí oddělit vlastní model od GUI.” | Two libraries: `core_fsm` (pure C++17, no Qt) and `ui_qt` (Qt Widgets). |
| **Single source of truth = text file** | “Umožní kompletní specifikaci automatu uložit do souboru … lze načíst a dále editovat.” | Design an **.fsm** YAML/JSON/TOML schema early; editor & code-gen must round-trip without loss. |
| **Run anywhere Qt ≥ 5.5** | toolkit requirement & Linux/Windows test on “merlin” | Target **Qt 5.12 LTS** (fully back-runs on 5.5); avoid Qt-6-only APIs. |


---

## 1  High-level Work-breakdown Structure

| Phase | Output artifact(s) | Key risks controlled |
|-------|--------------------|----------------------|
| **P0 – Kick-off & tooling** (½ week) | - Repo scaffold (`src/`, `doc/`, `examples/`)  <br>- Continuous Integration on GitHub/GitLab | Build/CI failure on “merlin” |
| **P1 – Domain model** (1 week) | - `core_fsm` C++17 library: `State`, `Transition`, `Variable`, `Event`, `Timer`, `Automaton`, `Scheduler`  <br>- Pure console interpreter with JSON I/O | Semantics of delayed transitions & guard precedence |
| **P2 – Persistence layer** (½ week) | - `fsm_schema.json`  <br>- Serializer/Deserializer (nlohmann-json)  <br>- | Round-trip fidelity |
| **P3 – Code generator** (1 week) | - `fsm_codegen` tool → emits single-file C++17 interpreter using core_fsm API  <br>- CMake target `make codegen && make run_generated` | Generated code divergence from runtime interpreter |
| **P4 – Runtime connector** (½ week) | - UDP (or QtLocalSocket) bridge library `io_bridge`  <br>- Message schema: `{timestamp, in[], out[], vars[]}` JSON | Latency / packet loss <br>-  |
| **P5 – Qt GUI foundation** (1 week) | - Skeleton `ui_qt` app with MDI, menu, docking log panel  <br>- Load/save .fsm, connect/disconnect <br> - Auto-connect on startup: attempt to attach to a running automaton, fetch its name & source, and display it | Qt-version inconsistency |
| **P6 – Diagram editor** (2 weeks) | - State/transition drawing using `QGraphicsView`  <br>- Property inspectors for guards & actions with syntax highlighting (`QsciScintilla`) | Usability, undo/redo |
| **P7 – Live monitor overlay** (1 week) | - Realtime highlight of active state  <br>- Tables for last values  <br>- Scrollable event log | Threading (socket → UI) |
| **P8 – Input injection tools** (½ week) | - “Inject value” dialog, quick toolbar buttons | Race conditions w/ timers |
| **P9 – Packaging & cross-platform tests** (½ week) | - `make`, `make run`, `make doxygen`, `make pack`  <br>- Windows cross-compile via `mingw` in CI | DLL/path issues |
| **P10 – Documentation & UML** (½ week) | - Doxygen HTML under `doc/`  <br>- `design.pdf` with class + sequence diagrams | Out-of-date diagrams |
| **P11 – Buffer / stretch goals** (1 week) | - Multiple automata (MQTT)  <br>- Petri-net variant | Time overrun |

_Total baseline: ≈ 10 effective weeks; fits 13-week semester with slack._

---

## 2  Detailed Task List (by Phase)

<details>
<summary>P0 Kick-off & Tooling</summary>

1. **Repo & CI**
   - Initialise Git; enable GitHub Actions with *Ubuntu-latest* matrix (gcc/clang), *macOS*, *windows*.
   - Pre-commit hooks: clang-format, CMake-lint.
2. **Build skeleton**
   - Minimal `main.cpp` (from earlier mock); proves Qt link on all runners.
3. **Issue tracking**
   - Tag backlog with `core`, `gui`, `codegen`, `docs`, `infra`.
</details>

<details>
<summary>P1 Domain model</summary>

| Class | Core responsibilities |
|-------|-----------------------|
| `Variable` | name, type‐string, `QVariant value` |
| `Event`    | input/output tag + `QString payload` |
| `Guard`    | *AST* parsed from inscription language; evaluate against variables + last inputs |
| `Action`   | sequence of output events / variable assignments |
| `Transition` | source, target, optional `input_name`, `Guard`, optional `delay_ms` |
| `State` | name, `Action onEnter` |
| `Automaton` | list of states/transitions, active state id |
| `Scheduler` | priority rules per spec (inputs > delay > ignore) |

</details>

<details>
<summary>P2 Persistence layer</summary>

*Schema outline* (YAML for readability; JSON on disk):

```yaml
name: TOF5s
comment: Timer to off…
inputs:  [ in ]
outputs: [ out ]
variables:
  - {name: timeout, type: int, init: 5000}
states:
  - {id: IDLE,    initial: true, onEnter: 'output(\"out\",0)'}
  - {id: ACTIVE,  onEnter: 'output(\"out\",1)'}
transitions:
  - {from: IDLE,   to: ACTIVE,  trigger: in, guard: 'atoi(valueof(\"in\"))==1'}
  - {from: ACTIVE, to: TIMING,  trigger: in, guard: 'atoi(valueof(\"in\"))==0'}
  - {from: TIMING, to: IDLE,    delay: timeout}
```

*Round-trip test*: load -> save -> diff must be empty (ignore whitespace).
</details>

<details>
<summary>P3 Code generator</summary>

Algorithm:

1. Read .fsm
2. Emit single C++ file:  
   - Hard-code states enum, variables struct.  
   - Switch-case inside `step()` handles guards + delays.  
3. Emit CMakeLists; build shared lib or exe.
4. Compare runtime traces between core interpreter and generated version (unit test).

Success metric: identical JSON log (>95 % token match).
</details>

<details>
<summary>P4 Runtime connector</summary>

*Protocol draft*

```text
// Input injection (editor → interpreter)
{ "type":"inject", "time":<ms>, "name":"in", "value":"1" }

// State broadcast (interpreter → editor)
{ "type":"state", "time":<ms>, "state":"ACTIVE",
  "inputs": { "in":"1"}, "vars": { "timeout":5000 }, "outputs": { "out":"1"} }
```

*Library*: Qt’s `QUdpSocket` or plain BSD on core side; Qt wrapper in UI thread via `QThread`.
</details>

<details>
<summary>P5 Qt GUI foundation</summary>

- `MainWindow` (Qt Designer)  
  - **Menu**: File-New/Open/Save, Build-Generate/Run, View-Log.  
  - **Dockable panels**: Properties, Event Log, Variables.  
  - **Central**: `FsmScene` (inherits `QGraphicsScene`).

Add action “Connect” which spawns socket thread.
</details>

<details>
<summary>P6 Diagram editor</summary>

*Milestones*:

1. **Static rendering** of loaded FSM.  
2. **Interactive** create/remove state/transition (Ctrl-drag).  
3. **Property editor** (right sidebar) using `QFormLayout`.  
4. **Undo/Redo** with `QUndoStack`.  
5. **Validation** on save (dangling transitions, duplicate IDs).

Guard/action text-editing via **QsciScintilla** (C-syntax highlight).
</details>

<details>
<summary>P7 Live monitor overlay</summary>

- Use `QGraphicsItem::setSelected()` or custom pen/brush to highlight active state (green glow).
- Move network handling to `FsmMonitorThread`; emit Qt signals.
- Log panel (`QTableView` + `QStandardItemModel`) timestamps (`QDateTime::currentMSecsSinceEpoch()`).

Performance target: sustain 1 k events/s without UI lag.
</details>

<details>
<summary>P8 Input injection tools</summary>

- Quick-access toolbar showing every input name; click opens inline editor (`QInputDialog`).
- Maintain history (combo-box arrow) for fast replay.
</details>

<details>
<summary>P9 Packaging</summary>

1. **Linux**: AppImage via linuxdeployqt.  
2. **Windows**: `windeployqt`, zip.  
3. **macOS**: `.app` bundle + `macdeployqt`.  
4. Verify `make clean && make pack` produces ≤ IS size limit.
</details>

<details>
<summary>P10 Documentation</summary>

- Enable `SOURCE_BROWSER = YES`, `EXTRACT_ALL = YES` in Doxyfile.  
- `design.pdf`:  
  - Class diagram (PlantUML).  
  - Sequence “Input event triggers delayed transition”.  
  - Deployment diagram (editor ↔ interpreter).
</details>

---

## 4  Risk & Mitigation Table

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| **Timer accuracy drift** | M | H | Central scheduler uses monotonic clock; unit tests inject virtual time. |
| GUI perf on large automata | M | M | Viewports with `QGraphicsView::CacheBackground`, level-of-detail. |
| Qt 5.5 missing newer APIs | H | L | Avoid Qt 6-only classes (e.g. `QStringView`); provide shims. |
| UDP blocked on campus net | L | M | Fallback to `QLocalSocket` or stdin/stdout pipes. |

---

## Useful info from other students
- We are allowed basically anything that will help us with this project as long as it fits the right version. Some students used `QStateMachine` and `QJSEngine`.

## Roadmap updates:
- P0 done - made github repo, made all project directories and a simple qt executable.